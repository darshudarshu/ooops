<?php
include "utilityadress.php";
include "addressbook.php";
$utilityref = new UtilityAdd();
$addadressref = new AddAdress();
$editadressref = new EditAdress();
$deleteaddresref = new DeleteAddress();
$sortaddresref = new Sort();
$openaddressbookref = new OpenBook();

echo "FOLLOW BELOW INSTRUCTION \n";
do {
    echo "enter 1 to add address \n";
    echo "enter 2 to edit address \n";
    echo "enter 3 to delete the adress \n";
    echo "enter 4 to sort the adressbook \n";
    echo "enter 5 to view the adressbook \n";
    $get = $utilityref->getInt();
    switch ($get) {
        case 1:echo "enter the no of address you want to add to AddressBook\n";
            $noOfAddress = $utilityref->getInt();
            for ($i = 0; $i < $noOfAddress; $i++) {
                $addadressref->addAddress($utilityref);
            }
            break;
        case 2:$editadressref->editTheAdress();
            break;
        case 3:$deleteaddresref->removeAddres();
            break;
        case 4:$sortaddresref->chooseSort($openaddressbookref);
            break;
        case 5:$openaddressbookref->phoneBookDisplay();
            break;
        default:echo "invalid entry \n";
            break;
    }
    echo "enter \n";
    echo "1:continue... \n";
    echo "2:exit from phonebook \n";
    $continue = $utilityref->getInt();
} while ($continue == 1);
