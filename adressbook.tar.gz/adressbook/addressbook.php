<?php
class AddressBook
{
    public $firstName;
    public $lastName;

    public function __construct($firstName, $lastName, $state, $city, $zipCode, $phoneNumber)
    {
        $this->firstName = $firstName;
        $this->lastName = $lastName;
        $this->address = array("State" => $state, "City" => $city,
            "Zipcode" => $zipCode,
            "PhoneNumber" => $phoneNumber);

    }
}
class AddAdress extends UtilityAdd
{
    public function addAddress()
    {
        echo "enter the User First Name \n";
        $firstName = UtilityAdd::stringData();
        echo "enter the User Last Name \n";
        $lastName = UtilityAdd::stringData();
        echo "enter the User State \n";
        $state = UtilityAdd::stringData();
        echo "enter the User City \n";
        $city = UtilityAdd::stringData();
        echo "enter the User Zip Code \n";
        $zipCode = UtilityAdd::zipNum();
        echo "enter the User Phone Number \n";
        $phoneNumber = UtilityAdd::moblieNumber();

        $addressbookref = new AddressBook($firstName, $lastName, $state, $city, $zipCode, $phoneNumber);
        echo "enter 1 to save adress to JSON \n";
        $check = UtilityAdd::getInt();
        if ($check == 1) {
            AddAdress::addToJsonFile($addressbookref);
        } else {
            echo "Addres is not saved \n";
        }
    }
    public function addToJsonFile($addressbookref)
    {
        $data = file_get_contents('address.json');
        $json_arr = json_decode($data, true);
        $json_arr[] = $addressbookref;
        file_put_contents('address.json', json_encode($json_arr));
    }

}
class EditAdress extends UtilityAdd
{
    public $index = null;
    public function editTheAdress()
    {
        if (EditAdress::searchAddress()) {
            $this->displaySpecificPerson($this->index);
            do {
                echo "enter 1 to edit State \n";
                echo "enter 2 to edit city \n";
                echo "enter 3 to edit ZipCode \n";
                echo "enter 4 to edit moblinumber \n";
                $get = UtilityAdd::getInt();
                switch ($get) {
                    case 1:
                        EditAdress::changeState();
                        break;
                    case 2:
                        EditAdress::changeCity();
                        break;
                    case 3:
                        EditAdress::changeZipcode();
                        break;
                    case 4:
                        EditAdress::changePhonenumber();
                        break;
                    default:echo "invalid entry \n";
                        EditAdress::editTheAdress();
                        break;
                }
                echo "enter \n";
                echo "1:edit further \n";
                echo "2:exit from edit operation \n";
                $continue = EditAdress::getInt();
            } while ($continue == 1);

        } else {
            echo "No such name address is found \n";
            $this->editTheAdress();
        }
    }
    public function changeState()
    {
        echo "enter new State \n";
        $name = UtilityAdd::stringData();
        $data = file_get_contents('address.json');
        $json_arr = json_decode($data, true);
        $json_arr[0]["address"]["State"] = $name;
        file_put_contents('address.json', json_encode($json_arr));
    }
    public function changeCity()
    {
        echo "enter new City \n";
        $name = UtilityAdd::stringData();
        $data = file_get_contents('address.json');
        $json_arr = json_decode($data, true);
        $json_arr[0]["address"]["City"] = $name;
        file_put_contents('address.json', json_encode($json_arr));

    }
    public function changeZipcode()
    {
        echo "enter new Zipcode \n";
        $num = UtilityAdd::zipNum();
        $data = file_get_contents('address.json');
        $json_arr = json_decode($data, true);
        $json_arr[0]["address"]["Zipcode"] = $num;
        file_put_contents('address.json', json_encode($json_arr));
    }
    public function changePhonenumber()
    {
        echo "enter new Phone Number \n";
        $num = UtilityAdd::moblieNumber();
        $data = file_get_contents('address.json');
        $json_arr = json_decode($data, true);
        $json_arr[0]["address"]["PhoneNumber"] = $num;
        file_put_contents('address.json', json_encode($json_arr));
    }
    public function searchAddress()
    {
        echo "enter the First name of user to change his/her address \n";
        $name = UtilityAdd::stringData();
        $data = file_get_contents('address.json');
        $json_arr = json_decode($data, true);
        $flag = 0;
        for ($i = 0; $i < count($json_arr); $i++) {
            if ($json_arr[$i]["firstName"] == $name) {
                echo "enter " . $i . " to EDIT this adress \n";
                $this->displaySpecificPerson($i);
                $flag = 1;
            }
        }
        if ($flag == 1) {
            $this->index = UtilityAdd::getInteger();
            return true;
        } else {
            return false;
        }

    }
    public function displaySpecificPerson($index)
    {
        $data = file_get_contents('address.json');
        $json_arr = json_decode($data, true);
        echo "User First Name : " . $json_arr[$index]["firstName"] . "\n";
        echo "User Last Name : " . $json_arr[$index]["lastName"] . "\n";
        echo "User Adress     : \n";
        echo "          State       : " . $json_arr[$index]["address"]["State"] . "\n";
        echo "          City        : " . $json_arr[$index]["address"]["City"] . "\n";
        echo "          Zipcode     : " . $json_arr[$index]["address"]["Zipcode"] . "\n";
        echo "          PhoneNumber : " . $json_arr[$index]["address"]["PhoneNumber"] . "\n";
        echo "\n";
    }
}
class DeleteAddress extends UtilityAdd
{
    public $index = null;
    public function removeAddres()
    {
        do {
            if (DeleteAddress::searchAddressToDelete()) {

                $json = array();
                $data = file_get_contents('address.json');
                $json_arr = json_decode($data, true);
                for ($i = 0; $i < count($json_arr); $i++) {
                    if ($i != $this->index) {
                        $json[] = $json_arr[$i];
                    }
                }
                file_put_contents('address.json', json_encode($json));
            } else {
                echo "No such name address is found \n";
                $this->removeAddres();
            }
            echo "enter \n";
            echo "1:delete further \n";
            echo "2:exit from delete operation \n";
            $continue = UtilityAdd::getInt();
        } while ($continue == 1);
    }
    public function searchAddressToDelete()
    {
        echo "enter the First name of user to change his/her address \n";
        $name = UtilityAdd::stringData();
        $data = file_get_contents('address.json');
        $json_arr = json_decode($data, true);
        $flag = 0;
        for ($i = 0; $i < count($json_arr); $i++) {
            if ($json_arr[$i]["firstName"] == $name) {
                echo "enter " . $i . " to delete this adress \n";
                $this->displaySpecificPerson($i);
                $flag = 1;
            }
        }
        if ($flag == 1) {
            $this->index = UtilityAdd::getInteger();
            return true;
        } else {
            return false;
        }

    }
    public function displaySpecificPerson($index)
    {
        $data = file_get_contents('address.json');
        $json_arr = json_decode($data, true);
        echo "User First Name : " . $json_arr[$index]["firstName"] . "\n";
        echo "User Last Name : " . $json_arr[$index]["lastName"] . "\n";
        echo "User Adress     : \n";
        echo "          State       : " . $json_arr[$index]["address"]["State"] . "\n";
        echo "          City        : " . $json_arr[$index]["address"]["City"] . "\n";
        echo "          Zipcode     : " . $json_arr[$index]["address"]["Zipcode"] . "\n";
        echo "          PhoneNumber : " . $json_arr[$index]["address"]["PhoneNumber"] . "\n";
        echo "\n";
    }
}
class Sort extends UtilityAdd
{
    public function chooseSort($openaddressbookref)
    {
        echo "enter 1 to sort based on first name \n";
        echo "enter 2 to sort based on last name \n";
        echo "enter 3 to sort based on Zipcode \n";
        $local = sort::getInteger();
        switch ($local) {
            case 1:
                $this->firstNameSort();
                break;
            case 2:
                $this->lastNameSort();
                break;
            case 3:
                $this->zipCodeSort();
                break;
            default:echo "invalid entry , enter again\n";
                $this->chooseSort();
                break;
        }
        echo "enter 1 to view sorted phonebook \n";
        echo "enter 2 to main mebu \n";
        $temp = sort::getInteger();
        if ($temp == 1) {
            $openaddressbookref->phoneBookDisplay();
        }

    }
    public function lastNameSort()
    {
        $data = file_get_contents('address.json');
        $json_arr = json_decode($data, true);
        for ($i = 0; $i < count($json_arr) - 1; $i++) {
            for ($j = $i + 1; $j < count($json_arr); $j++) {
                if ($json_arr[$i]["lastName"] > $json_arr[$j]["lastName"]) {
                    Sort::swap($i, $j);
                }
            }
        }
    }
    public function zipCodeSort()
    {
        $data = file_get_contents('address.json');
        $json_arr = json_decode($data, true);
        for ($i = 0; $i < count($json_arr) - 1; $i++) {
            for ($j = $i + 1; $j < count($json_arr); $j++) {
                if ($json_arr[$i]["address"]["Zipcode"] > $json_arr[$j]["address"]["Zipcode"]) {
                    Sort::swap($i, $j);
                }
            }
        }
    }
    public function firstNameSort()
    {
        $data = file_get_contents('address.json');
        $json_arr = json_decode($data, true);
        for ($i = 0; $i < count($json_arr) - 1; $i++) {
            for ($j = $i + 1; $j < count($json_arr); $j++) {
                if ($json_arr[$i]["firstName"] > $json_arr[$j]["firstName"]) {
                    Sort::swap($i, $j);
                }
            }
        }
    }
    public function swap($a, $b)
    {
        $data = file_get_contents('address.json');
        $json_arr = json_decode($data, true);
        $temp = array();
        $temp = $json_arr[$a];
        $json_arr[$a] = $json_arr[$b];
        $json_arr[$b] = $temp;
        file_put_contents('address.json', json_encode($json_arr));
    }
}
class OpenBook
{
    public function phoneBookDisplay()
    {
        $data = file_get_contents('address.json');
        $json_arr = json_decode($data, true);
        for ($i = 0; $i < count($json_arr); $i++) {
            OpenBook::displaySpecificPerson($i);
            echo "\n";
        }
    }
    public function displaySpecificPerson($index)
    {
        $data = file_get_contents('address.json');
        $json_arr = json_decode($data, true);
        echo "User First Name : " . $json_arr[$index]["firstName"] . "\n";
        echo "User Last Name : " . $json_arr[$index]["lastName"] . "\n";
        echo "User Adress     : \n";
        echo "          State       : " . $json_arr[$index]["address"]["State"] . "\n";
        echo "          City        : " . $json_arr[$index]["address"]["City"] . "\n";
        echo "          Zipcode     : " . $json_arr[$index]["address"]["Zipcode"] . "\n";
        echo "          PhoneNumber : " . $json_arr[$index]["address"]["PhoneNumber"] . "\n";
        echo "\n";
    }
}
